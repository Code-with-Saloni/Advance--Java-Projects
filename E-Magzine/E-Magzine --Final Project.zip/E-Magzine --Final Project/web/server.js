/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// server.js
const express = require('express');
const stripe = require('stripe')('YOUR_SECRET_KEY'); // Replace with your Stripe secret key
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public')); // Serve your HTML file from the 'public' directory

// Endpoint to create a subscription
app.post('/create-subscription', async (req, res) => {
    const { email, planId } = req.body;

    try {
        // Create a new customer
        const customer = await stripe.customers.create({
            email: email,
            payment_method: req.body.payment_method, // This will be added later
            invoice_settings: {
                default_payment_method: req.body.payment_method,
            },
        });

        // Create a subscription for the customer
        const subscription = await stripe.subscriptions.create({
            customer: customer.id,
            items: [{ plan: planId }],
            expand: ['latest_invoice.payment_intent'],
        });

        res.send({
            subscriptionId: subscription.id,
            clientSecret: subscription.latest_invoice.payment_intent.client_secret,
        });
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});



